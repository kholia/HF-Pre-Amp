# PG-TIA
Programmable-gain termination-insensitive IF amplifier.
