# TIA-AGC
A termination-insensitive IF amplifier with AGC.
